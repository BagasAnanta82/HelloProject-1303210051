package main

import (
	"fmt"
)

type set [2022]int

func main() {
	var set1, set2, set3 set
	var n1, n2, n3 int
	inputSet(&set1, &n1)
	inputSet(&set2, &n2)
	findIntersection(set1, set2, n1, n2, &set3, &n3)
	printSet(set3, n3)

}

func exist(T set, n int, val int) bool {
	var cek bool
	cek = false
	for i := 0; i < n && !cek; i++ {
		if T[i] == val {
			cek = true
		}
	}
	return cek
}

func inputSet(T *set, n *int) {
	var kondisi bool
	kondisi = false

	fmt.Scan(&T[*n])
	kondisi = exist(*T, *n, T[*n])
	for !kondisi {
		*n++
		fmt.Scan(&T[*n])
		kondisi = exist(*T, *n, T[*n])
	}
}

func findIntersection(T1, T2 set, n, m int, T3 *set, h *int) {
	for i := 0; i < n; i++ {
		for jml := 0; jml < m; jml++ {
			if T1[i] == T2[jml] {
				if !exist(*T3, *h, T1[i]) {
					T3[*h] = T1[i]
					*h++
				}
			}
		}
	}
}

func printSet(T set, n int) {
	for i := 0; i < n; i++ {
		fmt.Print(T[i], " ")
	}
}
